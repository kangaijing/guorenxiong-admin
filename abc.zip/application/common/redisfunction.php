<?php
/*
** Redis 业务处理函数库
** 函数请带上 redis_ 前缀
*/


