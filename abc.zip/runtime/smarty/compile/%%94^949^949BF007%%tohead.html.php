<?php /* Smarty version 2.6.30, created on 2017-03-16 10:00:30
         compiled from public/tohead.html */ ?>
<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link href="/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
	<link href="/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
	<link href="/css/style.css" rel="stylesheet" />
	
	