<?php /* Smarty version 2.6.30, created on 2017-03-16 10:00:30
         compiled from public/footer.html */ ?>
<script src="/js/jquery.min.js"></script>
<script src="/bootstrap/js/bootstrap.min.js"></script>
<script src="/js/layer/layer.js"></script>
<script src="/js/common.js"></script>